from PIL import Image
import MATH

image = Image.open('BW.bmp')
pixels = image.load()

i = 0
j = 0
z = 0

for a in range(0, 256, 255):
    for b in range(0, 256, 255):
        for c in range(0, 256, 255):
            for d in range(0, 256, 255): 
                for e in range(0, 256, 255):
                    for f in range(0, 256, 255):
                        for g in range(0, 256, 255):
                            for h in range(0, 256, 255):
                                for q in range(0, 256, 255):
                                    for r in range(0, 256, 255):
                                        for k in range(0, 256, 255):
                                            for l in range(0, 256, 255):
                                                for m in range(0, 256, 255):
                                                    for n in range(0, 256, 255):
                                                        for o in range(0, 256, 255):
                                                            for p in range(0, 256, 255):
                                                                pixels[i, j] = (a, a, a)
                                                                i += 1
                                                                pixels[i, j] = (b, b, b)
                                                                i += 1
                                                                pixels[i, j] = (c, c, c)
                                                                i += 1
                                                                pixels[i, j] = (d, d, d)
                                                                j += 1
                                                                i -= 3
                                                                pixels[i, j] = (e, e, e)
                                                                i += 1
                                                                pixels[i, j] = (f, f, f)
                                                                i += 1
                                                                pixels[i, j] = (g, g, g)
                                                                i += 1
                                                                pixels[i, j] = (h, h, h)
                                                                j += 1
                                                                i -= 3
                                                                pixels[i, j] = (q, q, q)
                                                                i += 1
                                                                pixels[i, j] = (r, r, r)
                                                                i += 1
                                                                pixels[i, j] = (k, k, k)
                                                                i += 1
                                                                pixels[i, j] = (l, l, l)
                                                                j += 1
                                                                i -= 3
                                                                pixels[i, j] = (m, m, m)
                                                                i += 1
                                                                pixels[i, j] = (n, n, n)
                                                                i += 1
                                                                pixels[i, j] = (o, o, o)
                                                                i += 1
                                                                pixels[i, j] = (p, p, p)
                                                                if(i >= 1285):
                                                                    i = 0
                                                                    j += 2
                                                                else:
                                                                    i += 2
                                                                    j -= 3
                                                                    z += 1
image.save('BWImage.bmp')